USB Benchmark Application 
-------------------------
The benchmark application is designed to work with specific hardware.
Any attempt to use this application on a usb device that was not 
designed for it will produce unpredictable result.

The Benchmark device firmware is available for PIC  USB MicroChip� microcontroller.
See the <LibUsbDotNet Install Directory>\Benchmark\Firmware.Pic.
